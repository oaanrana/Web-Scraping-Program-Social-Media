import twint

def get_followings(username):

    c = twint.Config()
    c.Username = username
    c.Pandas = True

    twint.run.Following(c)
    list_of_followings = twint.storage.panda.Follow_df

    return list_of_followings['following'][username]

    # return list_of_followings['following'][username]

followings = {}
following_list = []
file = open('/Users/ahmed/workspace/personal/twitterstream/gmu_cos_followers.csv')
file_write = open('/Users/ahmed/workspace/personal/twitterstream/output.csv', 'w')

for user in file:
    print('#####\nStarting: ' + user + '\n#####')
    try:
        followings[user] = get_followings(user).count()
        print(followings[user])
        # following_list = following_list + followings[user]
        break
    except KeyError:
        print('IndexError')


# print(followings)
# print("END")



