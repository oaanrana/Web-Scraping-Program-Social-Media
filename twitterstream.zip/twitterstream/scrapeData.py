import random

import requests
from bs4 import BeautifulSoup


def handle_data(text, user, url):
    line = '%s,%s,%s,%s\n' % (user.strip(),url.strip(), text[0], text[2])
    print(line)
    return line

# def old_user_list():
#     read_old_output = open('/Users/ahmed/workspace/personal/twitterstream/.csv')
#     read_lines = read_old_output.readlines();

#     old_users = []

#     for line in read_lines:
#         line_split = line.split(',')
#         old_users.append(line_split[0])

#     return old_users;

url = 'https://twitter.com/'
useragents = ['Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36',
                 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36',
                 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36',
                 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/602.2.14 (KHTML, like Gecko) Version/10.0.1 Safari/602.2.14',
                 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36',
                 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36',
                 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36',
                 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36',
                 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36',
                 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0']



read_file = open('/Users/oaanrana/Desktop/Work COS Stuff/Twitter Accounts/CHSS_Followers.csv')
file_write = open('/Users/oaanrana/Desktop/Work COS Stuff/Twitter Accounts/output_CHHS_followers.csv', 'w')
file_write.write('user,profile_link,follower_count,following_count\n')


file_write_error = open('/Users/oaanrana/Desktop/Work COS Stuff/Twitter Accounts/output_error_CHHS.csv', 'w')
for user in read_file:
    temp_url = url + user
    r = requests.get(temp_url, headers={'User-Agent': random.choice(useragents)})
    soup = BeautifulSoup(r.text, 'html.parser')
    try:
        general_data = soup.find_all('meta', attrs={'property': 'og:description'})
        text = general_data[0].get('content').split()
        line = handle_data(text, user.strip(), temp_url)
        file_write.write(line)
    except:
        print(f"failed this user: {temp_url}")
        continue


        




# for a in soup.findAll('div', href=True, attrs={'class':'css-1dbjc4n r-18u37iz r-1w6e6rj r-1h2hfjv'}):
#     followers = a.find('div', attrs={'class':'css-1dbjc4n r-1g94qm0'})
#     print(followers)





# <div class="css-1dbjc4n r-18u37iz r-1w6e6rj r-1h2hfjv"><div class="css-1dbjc4n r-1mf7evn r-1g94qm0"><a title="321" href="/_oaan/following" dir="auto" role="link" data-focusable="true" class="css-4rbku5 css-18t94o4 css-901oao r-jwli3a r-1loqt21 r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-vw2c0b r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">321</span></span> <span class="css-901oao css-16my406 r-111h2gw r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Following</span></span></a></div><div class="css-1dbjc4n r-1g94qm0"><a title="323" href="/_oaan/followers" dir="auto" role="link" data-focusable="true" class="css-4rbku5 css-18t94o4 css-901oao r-jwli3a r-1loqt21 r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-vw2c0b r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">323</span></span> <span class="css-901oao css-16my406 r-111h2gw r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Followers</span></span></a></div></div>
# <div class="css-1dbjc4n r-1g94qm0"><a title="323" href="/_oaan/followers" dir="auto" role="link" data-focusable="true" class="css-4rbku5 css-18t94o4 css-901oao r-jwli3a r-1loqt21 r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-vw2c0b r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">323</span></span> <span class="css-901oao css-16my406 r-111h2gw r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Followers</span></span></a></div>