# this code will be trying to return yes or no for whether or not that department's
# followers follow the college of science or not, yessssirrrr

# we will need to read the COS followers and department that we are checking
# and return a CSV file that will tell us if they DO follow or do not

cos_file = open(
    "/Users/oaanrana/Desktop/Work COS Stuff/Social_Media_Audit/twitterstream/gmu_cos_followers.csv",
    "r")

current_file = open(
    "/Users/oaanrana/Desktop/Work COS Stuff/Social_Media_Audit/Twitter Accounts/CEHD_Twitter_Info/output_CEHD_followers.csv")

true_false_file = open(
    '/Users/oaanrana/Desktop/Work COS Stuff/Social_Media_Audit/Twitter Accounts/CEHD_Twitter_Info/CEHD_COS_Compare.csv',
    'w')

cos_list = cos_file.readlines()

dept_list = current_file.readlines()

for index in range(len(dept_list)):
    if index == 0:
        continue
    line = dept_list[index].split(",")
    user = line[0].lower()
    if (user + "\n") in cos_list:
        true_false_file.write("TRUE\n")
    else:
        true_false_file.write("FALSE\n")
