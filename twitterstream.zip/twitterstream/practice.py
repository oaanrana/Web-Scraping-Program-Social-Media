from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd


# def handle_data(text, user, url):
#     full_text = text.split('\n')
#     for line in full_text:
#         temp = line.split(' ')
#         if len(temp)>1 and temp[1] == 'Following':
#             following = temp[0]
#         elif len(temp)>1 and temp[1] == 'Followers':
#             followers = temp[0]
#     line = '%s,%s,%s,%s\n' % (user.strip(),url.strip(), followers, following)
#     print(line)
#     return line
    



# url = 'https://twitter.com/lanale103'

# driver = webdriver.Chrome("/Users/ahmed/Downloads/chromedriver")

# driver.get(url)

# followers = driver.find_element_by_class_name('css-1dbjc4n')
# user = 'something'
# url = 'something.com'

# handle_data(followers.text, user, url)

# driver.quit()





read_old_output = open('/Users/ahmed/workspace/personal/twitterstream/output1.csv')
read_lines = read_old_output.readlines();

old_users = []

for line in read_lines:
    line_split = line.split(',')
    old_users.append(line_split[0])

print('seandiment' in old_users)